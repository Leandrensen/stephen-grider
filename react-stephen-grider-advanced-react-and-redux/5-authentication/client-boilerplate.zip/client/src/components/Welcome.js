import React from 'react';

export default () => {
  return <h3>Welcome! Sign up or sign in!</h3>;
};
